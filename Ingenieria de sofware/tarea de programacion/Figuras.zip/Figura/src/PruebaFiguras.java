public class PruebaFiguras {

    public static void main(String[] args) {

        // ---- CÍRCULO ----
        Circulo circulo = new Circulo(5);
        System.out.println("===== CÍRCULO =====");
        System.out.println("Radio: " + circulo.radio + " cm");
        System.out.printf("Área: %.2f cm²%n", circulo.calcularArea());
        System.out.printf("Perímetro (circunferencia): %.2f cm%n", circulo.calcularPerimetro());

        // ---- RECTÁNGULO ----
        Rectangulo rectangulo = new Rectangulo(8, 4);
        System.out.println("\n===== RECTÁNGULO =====");
        System.out.println("Base: " + rectangulo.base + " cm | Altura: " + rectangulo.altura + " cm");
        System.out.printf("Área: %.2f cm²%n", rectangulo.calcularArea());
        System.out.printf("Perímetro: %.2f cm%n", rectangulo.calcularPerimetro());

        // ---- CUADRADO ----
        Cuadrado cuadrado = new Cuadrado(6);
        System.out.println("\n===== CUADRADO =====");
        System.out.println("Lado: " + cuadrado.lado + " cm");
        System.out.printf("Área: %.2f cm²%n", cuadrado.calcularArea());
        System.out.printf("Perímetro: %.2f cm%n", cuadrado.calcularPerimetro());

        // ---- TRIÁNGULO RECTÁNGULO ----
        TrianguloRectangulo triangulo = new TrianguloRectangulo(3, 4);
        System.out.println("\n===== TRIÁNGULO RECTÁNGULO =====");
        System.out.println("Base: " + triangulo.base + " cm | Altura: " + triangulo.altura + " cm");
        System.out.printf("Área: %.2f cm²%n", triangulo.calcularArea());
        System.out.printf("Hipotenusa: %.2f cm%n", triangulo.calcularHipotenusa());
        System.out.printf("Perímetro: %.2f cm%n", triangulo.calcularPerimetro());
        triangulo.determinarTipoTriangulo();
    }
}
