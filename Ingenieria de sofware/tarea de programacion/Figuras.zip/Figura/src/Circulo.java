public class Circulo {
    int radio;

    // Constructor
    public Circulo(int radio) {
        this.radio = radio;
    }

    // Método con retorno: calcula el área del círculo
    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    // Método con retorno: calcula el perímetro (circunferencia) del círculo
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }
}
