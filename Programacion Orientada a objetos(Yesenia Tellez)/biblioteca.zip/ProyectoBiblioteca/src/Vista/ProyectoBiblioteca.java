/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vista;

/**
 *
 * @author Jhon fonseca
 */
import Conexion.Conexion;
import Controlador.UsuarioController;
import Modelo.Usuario;
import java.util.List;
import java.util.Scanner;

public class ProyectoBiblioteca {

    public static void main(String[] args) {

        Scanner sa = new Scanner(System.in);
        UsuarioController controller = new UsuarioController();

        int opcion;

        do {
            Conexion cn = new Conexion();
            System.out.println("---------Registrar Usuario--------");
            System.out.println("1. Guardar Usuario");
            System.out.println("2. Mostrar lista de usuario");
            System.out.println("3. Salir");
            System.out.print("Opción: ");

            opcion = sa.nextInt();
            sa.nextLine();

            switch (opcion) {

                case 1:
                    System.out.print("Nombre del Usuario: ");
                    String nombre = sa.nextLine();

                    System.out.print("Apellido del usuario: ");
                    String apellido = sa.nextLine();

                    System.out.print("Telefono del usuario: ");
                    String telefono = sa.nextLine();

                    System.out.print("Tipo usuario: ");
                    String tipo_usuario = sa.nextLine();

                    System.out.print("Sección: ");
                    String seccion = sa.nextLine();

                    System.out.print("Año: ");
                    String año = sa.nextLine();

                    System.out.print("Código: ");
                    String codigo = sa.nextLine();

                    if (controller.guardar(nombre, apellido, telefono, tipo_usuario, seccion, año, codigo)) {
                        System.out.println("Usuario guardado");
                    } else {
                        System.out.println("Error al guardar");
                    }

                    break;

                case 2:
                    List<Usuario> lista = controller.obtener();

                    System.out.println("\n--- Lista de usuarios ---");
                    for (Usuario e : lista) {
                        System.out.println(
                                e.getNombre() + "-"
                                + e.getApellido() + "-"
                                + e.getTelefono() + "-"
                                + e.getTipo_usuario() + "-"
                                + e.getSeccion() + "-"
                                + e.getAño() + "-"
                                + e.getCodigo()
                        );

                    }
                    break;
            }
        } while (opcion != 0);
    }
}
