
package Controlador;

/**
 *
 * @author Jhon fonseca
 */
import Modelo.DAOUsuario;
import Modelo.Usuario;
import java.util.List;

public class UsuarioController {
    private DAOUsuario dao = new DAOUsuario();
     
    public List<Usuario> obtener(){
   return dao.listar();
   }   
    public boolean guardar (  String nombre, String apellido,String telefono, String tipo_usuario, String seccion, String año, String codigo){
        Usuario e =new Usuario (nombre,apellido,telefono,seccion,tipo_usuario,año,codigo);
       return dao.guardar(e);
    }
        
}
 