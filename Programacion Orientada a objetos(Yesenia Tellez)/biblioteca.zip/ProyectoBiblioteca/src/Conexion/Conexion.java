/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Jhon fonseca
 */
public class Conexion {
 
    private static final String URL
            ="jdbc:mysql://localhost/biblionet";
    private static final String USER = "root";
    private static final String PASSWORD = "Jhon89113637";
    
    public static Connection conectar() {
   Connection con = null;
    try {
        con = DriverManager.getConnection(
        URL,
        USER,
        PASSWORD 
                );
        System.out.print("Conexion exitosa");
    } catch (Exception e){
        System.out.print("Error: "+ e.getMessage());
      
    }
    return con;
    }
}
