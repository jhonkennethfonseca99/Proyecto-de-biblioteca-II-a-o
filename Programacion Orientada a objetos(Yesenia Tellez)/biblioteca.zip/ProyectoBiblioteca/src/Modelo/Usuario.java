/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Jhon fonseca
 */
public class Usuario {
    private int id_usuario;
    private String nombre;
    private String apellido;
    private String telefono;
    private String tipo_usuario;
    private String seccion;
    private String año;
    private String codigo;

    public Usuario(String nombre, String apellido, String telefono, String tipo_usuario, String seccion, String año, String codigo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.tipo_usuario = tipo_usuario;
        this.seccion = seccion;
        this.año = año;
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getTipo_usuario() {
        return tipo_usuario;
    }

    public String getSeccion() {
        return seccion;
    }

    public String getAño() {
        return año;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setTipo_usuario(String tipo_usuario) {
        this.tipo_usuario = tipo_usuario;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public void setAño(String año) {
        this.año = año;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
   
}
