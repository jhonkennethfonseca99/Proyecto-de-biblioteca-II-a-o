/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DAOUsuario {
    // Mostrar 

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "select * FROM Usuario";

        try (Connection con = Conexion.conectar(); PreparedStatement ps = con.prepareCall(sql); ResultSet rs = ps.executeQuery();) {
            while (rs.next()) {
                Usuario e = new Usuario(
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("telefono"),
                        rs.getString("seccion"),
                        rs.getString("tipo_usuario"),
                        rs.getString("año"),
                        rs.getString("codigo")
                );

                lista.add(e);
            }
        } catch (Exception e) {
            System.out.print("Error" + e.getMessage());
        }

        return lista;
    }

    public boolean guardar(Usuario e) {
        String sql
                = "INSERT INTO usuario(nombre, apellido, telefono, seccion, tipo_usuario, año, codigo) "
                + "VALUES (?,?,?,?,?,?,?)";
        try (
                Connection con = Conexion.conectar(); 
                PreparedStatement ps = con.prepareStatement(sql)
                )
        
        {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getApellido());
            ps.setString(3, e.getTelefono());
            ps.setString(4, e.getSeccion());
            ps.setString(5, e.getTipo_usuario());
            ps.setString(6, e.getAño());
            ps.setString(7, e.getCodigo());

            int filas = ps.executeUpdate();

            return filas > 0;

        }catch (Exception ex){
            
            System.out.println("Error: " + ex.getMessage());
            
            return false;
        }   
    }
}
