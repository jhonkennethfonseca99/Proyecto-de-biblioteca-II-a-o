
package autolote;

public class Autolote { 
    public static void main(String[] args) {
Carro carro= new Carro (4, "Toyota", "Agya 2026");
carro.mostrarDatos();
carro.AumentarVelocidad(60);
        
Moto moto = new Moto ("Yamaha", "R15", 150);
moto.mostrarDatos();
moto.AumentarVelocidad(40);
moto.AumentarVelocidad(40);
    }
    
    

}
