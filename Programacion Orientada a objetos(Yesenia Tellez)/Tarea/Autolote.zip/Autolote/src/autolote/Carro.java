
package autolote;
public class Carro extends Vehiculo{
    protected int numeropuertas;
    
    public Carro (int numeropuertas, String marca, String modelo){
        super (marca, modelo);
        this.numeropuertas = numeropuertas;
        
    }
    
    
    @Override
    public void mostrarDatos(){
        super.mostrarDatos();
        System.out.println("Múmero de puertas" + numeropuertas);
    }

    }

