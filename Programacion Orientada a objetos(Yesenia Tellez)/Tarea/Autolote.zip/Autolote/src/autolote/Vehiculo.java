
package autolote;
public class Vehiculo { //clase padre
    protected String marca;
    protected String modelo;
    protected int velocidad = 0;
    
    public Vehiculo (String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    protected void AumentarVelocidad (int incremento){
        this.velocidad+= incremento;
    System.out.println("velocidad en:" + velocidad);

    }
    protected void mostrarDatos (){
        System.out.println( "Marca:" + marca);
        System.out.println( "Modelo:" + modelo);
    }
}
