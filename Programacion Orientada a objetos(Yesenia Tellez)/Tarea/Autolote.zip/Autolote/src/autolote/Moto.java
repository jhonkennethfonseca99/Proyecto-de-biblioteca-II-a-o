
package autolote;
public class Moto extends Vehiculo {
    protected int cilindraje;
    
    public Moto (String marca, String modelo, int cilindraje){
        super (marca, modelo);
        this.cilindraje = cilindraje;
        
    }
    
    @Override
    public void mostrarDatos(){
        super.mostrarDatos();
        System.out.println("Cilindraje" + cilindraje);
    }

    
}
