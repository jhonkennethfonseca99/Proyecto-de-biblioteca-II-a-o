/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autolote;

/**
 *
 * @author Jhon fonseca
 */
public class Moto extends Vehiculo { //extented significa hereda de vehiculo
    protected int cilindraje;//pretected significa que los datos estan protegido
   
    public Moto(String marca,String modelo, int cilindraje){
       super(marca, modelo); //significa de que hereda  de la clase padre
    this.cilindraje = cilindraje;
    }        
    @Override //significa sobre escribe
    
    public void mostrarDatos(){
        super.mostrarDatos(); //significa lo de la clase padre
        System.out.println("Cilindra" +cilindraje);
    }
}

