 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package autolote;

/**
 *
 * @author Jhon fonseca
 */
public class Autolote {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Carro carro=new Carro(4,"toyota", "Aqya 2026");
      carro.mostrarDatos();
      carro.aumentarVelocidad(50);
      
      Moto moto =new Moto ("Yamaha","R15",150);
      moto.mostrarDatos();
      moto.aumentarVelocidad(40);
      moto.aumentarVelocidad(40);
    }
    
    
}
