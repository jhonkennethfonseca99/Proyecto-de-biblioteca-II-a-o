/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autolote;


public class Carro extends Vehiculo {
    protected int numerodepuertas;

    public Carro(int numerodepuertas, String Marca, String Modelo){
        super (Marca,Modelo);
        this.numerodepuertas = numerodepuertas;
    }
    @Override //significa sobre escribe
    
    public void mostrarDatos(){
        super.mostrarDatos(); //significa lo de la clase padre
        System.out.println("Numero de puertas" +numerodepuertas);
    }
}