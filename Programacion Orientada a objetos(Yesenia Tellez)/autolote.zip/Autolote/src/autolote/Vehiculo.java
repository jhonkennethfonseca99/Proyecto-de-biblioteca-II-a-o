/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autolote;

/**
 *
 * @author Jhon fonseca
 */
public class Vehiculo {
    protected String marca;
    protected String modelo;
    protected int velocidad=0;
    
    public Vehiculo(String Marca,String Modelo){
    this.marca=Marca;
    this.modelo=Modelo;
}
protected void mostrarDatos(){
    System.out.println("Marca:"+ marca);
    System.out.println("Modelo:"+ modelo);
}
protected void aumentarVelocidad(int valor){
    velocidad+=valor;
    System.out.println( "Velocidad en:"+velocidad);
}
}

 